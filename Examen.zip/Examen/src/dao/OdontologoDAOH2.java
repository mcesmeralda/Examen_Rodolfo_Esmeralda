package dao;

import model.Domicilio;
import model.Odontologo;
import model.Paciente;
import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;


public class OdontologoDAOH2 implements iDao<Odontologo> {

    private static final Logger logger = Logger.getLogger(OdontologoDAOH2.class);
    private static final String SQL_INSERT = "INSERT INTO ODONTOLOGOS (MATRICULA, NOMBRE, APELLIDO) VALUES (?, ?, ?)";
    private static final String SQL_SELECT_ALL = "SELECT * FROM ODONTOLOGOS";

    @Override
    public Odontologo guardar(Odontologo odontologo) {
        logger.info("Iniciando la operación de guardar un odontólogo");
        Connection connection = null;
        try {
            connection = BD.getConnection();
            PreparedStatement psInsert = connection.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
            psInsert.setString(1, odontologo.getMatricula());
            psInsert.setString(2, odontologo.getNombre());
            psInsert.setString(3, odontologo.getApellido());
            psInsert.executeUpdate();

            ResultSet rs = psInsert.getGeneratedKeys();
            if (rs.next()) {
                odontologo.setId(rs.getInt(1));
            }

            logger.info("Odontólogo guardado con éxito: " + odontologo);
        } catch (SQLException e) {
            logger.error("Error al guardar el odontólogo: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (SQLException e) {
                logger.error("Error al cerrar la conexión: " + e.getMessage());
            }
        }
        return odontologo;
    }

    @Override
    public Odontologo buscarPorId(Integer id) {
        return null;
    }





        @Override
        public void eliminar (Integer id){

        }

        @Override
        public void actualizar (Odontologo odontologo){

        }

        @Override
        public List<Odontologo> buscarTodos () {
                logger.info("Iniciando la operación de listar todos los odontólogos");
                Connection connection = null;
                List<Odontologo> odontologos = new ArrayList<>();
                try {
                    connection = BD.getConnection();
                    Statement statement = connection.createStatement();
                    ResultSet rs = statement.executeQuery(SQL_SELECT_ALL);

                    while (rs.next()) {
                        Odontologo odontologo = new Odontologo( rs.getString("NOMBRE"),rs.getInt("ID"),rs.getString("MATRICULA"), rs.getString("APELLIDO"));
                        odontologos.add(odontologo);
                    }

                    logger.info("Odontólogos listados con éxito");
                } catch (Exception e) {
                    logger.error("Error al listar los odontólogos: " + e.getMessage());
                } finally {
                    try {
                        if (connection != null) connection.close();
                    } catch (SQLException e) {
                        logger.error("Error al cerrar la conexión: " + e.getMessage());
                    }
                }
                return odontologos;
            }
        }

/*private Integer id;
private String nombre;
private Integer matricula;
private String apellido;*/