import dao.BD;
import model.Odontologo;
import model.Paciente;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import service.OdontologoService;
import service.PacienteService;

import java.util.List;

public class OdontologoServiceTest {
    private OdontologoService odontologoService;

    @BeforeEach
    public void setUp() {
        odontologoService = new OdontologoService();
        BD.crearTablas();
        PacienteService pacienteService= new PacienteService();
        Integer id=2;
        Odontologo odontologo= OdontologoService;
        Assertions.assertTrue(paciente!=null);// Asegúrate de que las tablas están creadas antes de cada test.
    }

    @Test
    public void testGuardarYListarOdontologo() {
        Odontologo odontologo1 = new Odontologo(null, "12345", "Juan", "Perez");
        Odontologo odontologo2 = new Odontologo(null, "67890", "Maria", "Gomez");

        odontologoService.guardarOdontologo(odontologo1);
        odontologoService.guardarOdontologo(odontologo2);

        List<Odontologo> odontologos = odontologoService.listarTodos();

        Assertions.assertFalse(odontologos.isEmpty());
        Assertions.assertEquals(2, odontologos.size());
    }
}


