package model;

public class Odontologo {
    private Integer id;
    private String matricula;
    private String nombre;
    private String apellido;

    public Odontologo(String nombre, Integer id, String matricula, String apellido) {
        this.nombre = nombre;
        this.id = id;
        this.matricula = matricula;
        this.apellido = apellido;
    }

    public Odontologo(String nombre, String matricula, String apellido) {
        this.nombre = nombre;
        this.matricula = matricula;
        this.apellido = apellido;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getMatricula() {
        return matricula;
    }
}
