package service;


import dao.OdontologoDAOH2;
import dao.iDao;
import model.Odontologo;

import java.util.List;

    public class OdontologoService {
        private iDao<Odontologo> OdontologoDao;

        public OdontologoService() {
            this.OdontologoDao = new OdontologoDAOH2();
        }

        public Odontologo guardarOdontologo(Odontologo odontologo) {
            return OdontologoDao.guardar(odontologo);
        }

        public List<Odontologo> listarTodos() {
            return OdontologoDao.buscarTodos();
        }
    }

